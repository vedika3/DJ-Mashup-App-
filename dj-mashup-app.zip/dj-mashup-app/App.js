import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';

export class Button1 extends Component {
  render() {
    return (
      <View>
        <Button color="black" title="Sound1"></Button>
      </View>
    );
  }
}

export class Button2 extends Component {
  render() {
    return (
      <View>
        <Button color="pink" title="Sound2"></Button>
      </View>
    );
  }
}

export class Button3 extends Component {
  render() {
    return (
      <View>
        <Button color="blue" title="Sound3"></Button>
      </View>
    );
  }
}

export class Button4 extends Component {
  render() {
    return (
      <View>
        <Button color="purple" title="Sound4"></Button>
      </View>
    );
  }
}

export default class App extends Component {
  render() {
    return (
      <View>
        <Text style={{ margin: 50 }}> DJ MASHUP app by VEDIKA SHUKLA </Text>
        <Button1 />
        <Button2 />
        <Button3 />
        <Button4 />
        <Text style={{ margin: 100 }}> Have Fun. </Text>
      </View>
    );
  }
}
